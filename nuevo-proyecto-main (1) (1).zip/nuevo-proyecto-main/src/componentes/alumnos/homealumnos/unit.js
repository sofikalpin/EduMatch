import React from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import "./articulos.css";
import LogoInicio from "../../../logo/LogoInicio.png";
import chatIcon from "../../../logo/chat.png";

const Unit = () => {
  const { id } = useParams(); // Obtiene el número de la unidad desde la URL

  const assignedArticles = [
    { id: 1, title: "Cómo utilizar el pasado en conversaciones cotidianas", image: "/images/articulo1.jpg", link: "/articulo/1", unidad: 1 },
    { id: 2, title: "Claves para mejorar tu pronunciación en inglés", image: "/images/articulo2.jpg", link: "/articulo/2", unidad: 2 },
    { id: 3, title: "Uso correcto de los verbos modales en inglés", image: "/images/articulo3.jpg", link: "/articulo/3", unidad: 2 },
    { id: 4, title: "Comprensión auditiva en inglés", image: "/images/articulo4.jpg", link: "/articulo/4", unidad: 3 },
    { id: 5, title: "Uso del presente perfecto", image: "/images/articulo5.jpg", link: "/articulo/5", unidad: 3 }
  ];

  // Filtrar los artículos que pertenecen a la unidad seleccionada
  const filteredArticles = assignedArticles.filter(article => article.unidad === parseInt(id));

  return (
    <div className="container">
      {/* Header */}
      <div className="header">
        <div className="nav-links">
          <img src={LogoInicio} alt="Logo" className="logo" />
          <Link to="/" className="nav-item">HOME</Link>
          <Link to="/courses" className="nav-item active">MY COURSES</Link>
          <Link to="/teachers" className="nav-item">TEACHERS</Link>
        </div>
        <div className="user-info">
          <span>Maria A</span>
          <div className="user-avatar">M</div>
          <div className="chat-icon-container">
            <img src={chatIcon} alt="Chat" className="chat-icon" />
          </div>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="content">
        <h1 className="title">Unit {id}</h1> 

        <div className="articles">
          {filteredArticles.length > 0 ? (
            filteredArticles.map((article) => (
              <div key={article.id} className="article-card">
                <Link to={article.link} className="article-link">
                  <img src={article.image} alt={article.title} className="article-image" />
                  <p className="article-title">{article.title}</p>
                </Link>
              </div>
            ))
          ) : (
            <p className="no-articles">No articles available in this unit.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Unit;
