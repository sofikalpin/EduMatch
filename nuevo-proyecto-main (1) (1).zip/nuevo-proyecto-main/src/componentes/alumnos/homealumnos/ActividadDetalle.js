import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./actividadDetalle.css";
import LogoInicio from "../../../logo/LogoInicio.png";
import chatIcon from "../../../logo/chat.png";
import logoactividad from "../../../logo/logoactividad.png";
import youtubeIcon from "../../../logo/youtube.png";
import driveIcon from "../../../logo/drive.png";
import uploadIcon from "../../../logo/upload.png";
import { FaSearch } from "react-icons/fa";

const ActividadDetalle = () => {
  const { id } = useParams(); // Obtiene el ID de la actividad desde la URL
  const navigate = useNavigate(); // Hook para navegación
  console.log("ID de la actividad:", id);

  // Estados para el componente
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [actividad, setActividad] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUnit, setSelectedUnit] = useState(null);
  const [unidades, setUnidades] = useState([]);
  const [isMenuOpen, setIsMenuOpen] = useState(false); // Estado para manejar el menú desplegable

  const youtubeInputRef = useRef(null);
  const driveInputRef = useRef(null);
  const uploadInputRef = useRef(null);

  // Lista de actividades (esto puede venir de una API)
  const actividades = [
    { id: "1", title: "Cómo utilizar los phrasal verbs en conversaciones cotidianas", description: "En esta actividad hay que completar con el phrasal verb que corresponde." },
    { id: "2", title: "Uso de tiempos verbales en inglés", description: "Practica el uso de los tiempos verbales en diferentes contextos." },
    { id: "3", title: "Preparación para el examen de listening", description: "Escucha el audio y responde las preguntas relacionadas." },
  ];

  useEffect(() => {
    // Busca la actividad correspondiente al ID desde la lista
    const actividadEncontrada = actividades.find((actividad) => actividad.id === id);
    if (actividadEncontrada) {
      setActividad(actividadEncontrada);
    }
  }, [id]);

  useEffect(() => {
    const unidadesAsignadas = Array.from({ length: 12 }, (_, i) => `Unit ${i + 1}`);
    setUnidades(unidadesAsignadas);
  }, []);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setSelectedUnit(null);
  };

  const handleUnitClick = (unitNumber) => {
    setSelectedUnit(unitNumber);
    setSearchQuery(`Unit ${unitNumber}`);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleMenuOptionClick = (option) => {
    switch(option) {
      case "Mi perfil":
        navigate("/mi-perfil"); // Redirige a la página de perfil
        break;
      case "Cambiar de cuenta":
        // Lógica para cambiar de cuenta
        break;
      case "Salir":
        // Lógica para salir (cerrar sesión)
        break;
      default:
        break;
    }
    setIsMenuOpen(false); // Cierra el menú después de seleccionar una opción
  };

  // Función para abrir el cuadro de diálogo de selección de archivos
  const handleUploadClick = (inputRef) => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  // Función para manejar el cambio de archivo y mostrar el nombre
  const handleFileChange = (event) => {
    const file = event.target.files[0]; // Obtiene el archivo seleccionado
    if (file) {
      setSelectedFile(file.name); // Guarda el nombre del archivo en el estado
      setLoading(true); // Muestra el indicador de carga
      setTimeout(() => {
        setLoading(false); // Después de un tiempo (simulando carga), se termina la carga
      }, 2000); // Simulamos una carga de 2 segundos
    }
  };

  // Simulamos la URL de un archivo subido por el profesor
  const archivoSubido = "https://www.example.com/archivo-actividad.pdf"; // Esto debería venir del backend

  if (!actividad) return <div>Cargando...</div>; // Si aún no se ha encontrado la actividad, muestra un mensaje

  // Función para entregar la actividad
  const handleSubmit = () => {
    setIsSubmitted(true); // Marca la actividad como entregada
    alert("Actividad entregada");
  };

  return (
    <div>
      <nav className="navbar">
        <div className="navbar-left">
          <img src={LogoInicio} alt="Logo" className="navbar-logo" />
          <a href="#inicio" onClick={() => navigate("/")}>INICIO</a>
          <a href="#mis-cursos" onClick={() => navigate("/miscursos")}>MIS CURSOS</a>
          <a href="#herramientas">PROFESORES</a>
        </div>
        <div className="navbar-right">
          <span>María A</span>
          <div className="icon" onClick={toggleMenu}> 
            <span className="icon-circle">M</span> 
          </div>
          <div className="chat-icon">
            <img src={chatIcon} alt="Chat" className="chat-icon-image" />
          </div>
          {isMenuOpen && (
            <div className="mini-container">
              <ul>
                <li onClick={() => handleMenuOptionClick("Mi perfil")}>Mi perfil</li>
                <li onClick={() => handleMenuOptionClick("Cambiar de cuenta")}>Cambiar de cuenta</li>
                <li onClick={() => handleMenuOptionClick("Salir")}>Salir</li>
              </ul>
            </div>
          )}
        </div>
      </nav>

      <div className="content">
        <div className="activity-container">
          <div className="activity-left">
            <h1 className="title">{actividad.title}</h1>
            <div className="activity-details">
              <img src={logoactividad} alt="Actividad" className="activity-image" />
              <p className="activity-description-label">Descripción:</p>
              <p className="activity-description">{actividad.description}</p>
              {archivoSubido && (
                <div className="uploaded-file-container">
                  <p>Archivo de la actividad:</p>
                  <a href={archivoSubido} download className="download-button">
                    Descargar actividad
                  </a>
                </div>
              )}
            </div>
          </div>

          <div className="activity-right">
            <div className="upload-container">
              <span className="due-date">Fecha de entrega: 25/08</span>
              <div className="upload-icons">
                <img
                  src={youtubeIcon}
                  alt="YouTube"
                  className="upload-icon"
                  onClick={() => handleUploadClick(youtubeInputRef)}
                />
                <input
                  type="file"
                  accept="video/*"
                  ref={youtubeInputRef}
                  className="file-input"
                  style={{ display: "none" }}
                  onChange={handleFileChange}
                />
                <img
                  src={driveIcon}
                  alt="Google Drive"
                  className="upload-icon"
                  onClick={() => handleUploadClick(driveInputRef)}
                />
                <input
                  type="file"
                  ref={driveInputRef}
                  className="file-input"
                  style={{ display: "none" }}
                  onChange={handleFileChange}
                />
                <img
                  src={uploadIcon}
                  alt="Subir archivo"
                  className="upload-icon"
                  onClick={() => handleUploadClick(uploadInputRef)}
                />
                <input
                  type="file"
                  ref={uploadInputRef}
                  className="file-input"
                  style={{ display: "none" }}
                  onChange={handleFileChange}
                />
              </div>
              {selectedFile && !loading && <p className="file-name">Archivo seleccionado: {selectedFile}</p>}
              {loading && <p className="loading">Cargando archivo...</p>}
            </div>

            <div className="activity-actions">
              <button
                className={`submit-button ${isSubmitted ? "submitted" : ""}`}
                onClick={handleSubmit}
                disabled={isSubmitted}
              >
                {isSubmitted ? "Actividad entregada" : "Entregar actividad"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActividadDetalle;
