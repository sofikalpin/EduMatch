import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import "./App.css";
import MisCursos from "./componentes/alumnos/homealumnos/miscursos";
import Cursos from "./componentes/alumnos/homealumnos/cursos";
import Articulos from "./componentes/alumnos/homealumnos/articulos";
import Actividades from "./componentes/alumnos/homealumnos/actividades"; // Importa Actividades.js
import Examenes from "./componentes/alumnos/homealumnos/examenes"; // Importa Examenes.js
import Unit from "./componentes/alumnos/homealumnos/unit"; // Importa Unit.js
import ExamenDetalle from "./componentes/alumnos/homealumnos/ExamenDetalle";
import ActividadDetalle from "./componentes/alumnos/homealumnos/ActividadDetalle";
import ArticuloDetalle from "./componentes/alumnos/homealumnos/ArticuloDetalle"; // Importa ArticuloDetalle.js

function App() {
  return (
    <Router>
      <Routes>
        {/* Redirige la raíz ("/") a "/miscursos" automáticamente */}
        <Route path="/" element={<Navigate to="/miscursos" />} />
        
        {/* Ruta para MisCursos */}
        <Route path="/miscursos" element={<MisCursos />} />
        
        {/* Ruta para Cursos */}
        <Route path="/cursos" element={<Cursos />} />

        {/* Ruta para Artículos */}
        <Route path="/articulos" element={<Articulos />} />

        {/* Ruta para el detalle de Artículos */}
        <Route path="/articulo/:id" element={<ArticuloDetalle />} />

        {/* Ruta para Actividades */}
        <Route path="/actividades" element={<Actividades />} />

        {/* Ruta para Exámenes */}
        <Route path="/examenes" element={<Examenes />} />

        {/* Ruta para el detalle de Exámenes */}
        <Route path="/examenes/:id" element={<ExamenDetalle />} />

        {/* Ruta para el detalle de Actividades */}
        <Route path="/actividades/:id" element={<ActividadDetalle />} />

        {/* Ruta para unidades (Unit) */}
        <Route path="/unit/:id" element={<Unit />} />
      </Routes>
    </Router>
  );
}

export default App;
