import React, { useState, useEffect } from "react";
import { FaSearch } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import "./examenes.css";
import LogoInicio from "../../../logo/LogoInicio.png";
import chatIcon from "../../../logo/chat.png";
import logoexamen from "../../../logo/logoexamen.png";
import articulo from "../../../logo/articulo.png";
import actividad from "../../../logo/actividades.png";
import foro from "../../../logo/foro.png";
import examen from "../../../logo/examen.png";

const Examenes = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUnit, setSelectedUnit] = useState(null);
  const [unidades, setUnidades] = useState([]);
  const [assignedExamenes, setAssignedExamenes] = useState([
    { id: 1, title: "Cómo utilizar el pasado en conversaciones cotidianas", link: "/examenes/1", unidad: 1 },
    { id: 2, title: "Claves para mejorar tu pronunciación en inglés", link: "/examenes/2", unidad: 2 },
    { id: 3, title: "Uso correcto de los verbos modales en inglés", link: "/examenes/3", unidad: 3 },
    { id: 4, title: "El presente perfecto en situaciones reales", link: "/examenes/4", unidad: 1 },
    { id: 5, title: "Diferencias entre 'must' y 'have to'", link: "/examen/5", unidad: 2 },
  ]);

  // Aquí agregamos el estado para el menú desplegable
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const unidadesAsignadas = Array.from({ length: 12 }, (_, i) => `Unit ${i + 1}`);
    setUnidades(unidadesAsignadas);
  }, []);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setSelectedUnit(null);
  };

  const handleUnitClick = (unitNumber) => {
    setSelectedUnit(unitNumber);
    setSearchQuery(`Unit ${unitNumber}`);
  };

  const filteredExamenes = assignedExamenes.filter(
    (examen) =>
      examen.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      `Unit ${examen.unidad}`.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const examenesForSelectedUnit = assignedExamenes.filter((examen) => examen.unidad === selectedUnit);
  const isUnitEmpty = selectedUnit !== null && examenesForSelectedUnit.length === 0;
  const isUnitSearch = searchQuery.toLowerCase().includes("unit");
  const searchUnitNumber = isUnitSearch ? parseInt(searchQuery.split(" ")[1], 10) : null;
  const isSearchUnitEmpty =
    searchUnitNumber && !assignedExamenes.some((examen) => examen.unidad === searchUnitNumber);

  // Usamos useNavigate para redirecciones
  const navigate = useNavigate();

  const handleCardClick = (option) => {
    switch(option) {
      case "Artículos":
        navigate("/articulos");
        break;
      case "Actividades":
        navigate("/actividades");
        break;
      case "Foro":
        navigate("/foro");
        break;
      case "Exámenes":
        navigate("/examenes");
        break;
      case "Mis Cursos": // Cuando se haga clic en Mis Cursos
        navigate("/miscursos");
        break;
      case "INICIO": // Cuando se haga clic en INICIO
        navigate("/"); // Esto redirige a la raíz
        break;
      default:
        break;
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleMenuOptionClick = (option) => {
    switch(option) {
      case "Mi perfil":
        navigate("/mi-perfil");
        break;
      case "Cambiar de cuenta":
        break;
      case "Salir":
        break;
      default:
        break;
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="container">
      <div className="header">
        <div className="navbar">
          <div className="navbar-left">
            <img src={LogoInicio} alt="Logo" className="navbar-logo" />
            <button onClick={() => handleCardClick("INICIO")}>INICIO</button>
            <button onClick={() => handleCardClick("Mis Cursos")}>MIS CURSOS</button>
            <button>PROFESORES</button>
          </div>
          <div className="navbar-right">
            <span>Maria A</span>
            <div className="icon" onClick={toggleMenu}> {/* Tocar el avatar abre el menú */}
              <span className="icon-circle">M</span> 
            </div>
            <div className="chat-icon">
              <img src={chatIcon} alt="Chat" className="chat-icon-image" />
            </div>
            {isMenuOpen && (
              <div className="mini-container">
                <ul>
                  <li onClick={() => handleMenuOptionClick("Mi perfil")}>Mi perfil</li>
                  <li onClick={() => handleMenuOptionClick("Cambiar de cuenta")}>Cambiar de cuenta</li>
                  <li onClick={() => handleMenuOptionClick("Salir")}>Salir</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="content">
        <h1 className="title">Examenes</h1>

        <div className="main-section">
          <div className="sidebar">
            <div className="search-box">
              <FaSearch className="search-icon" />
              <input
                type="text"
                placeholder="Search examen or Unit"
                className="search-input"
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
            <div className="unit-list">
              {unidades.map((unit, index) => {
                const unitNumber = index + 1;
                return (
                  <div key={index} className="unit-item">
                    <button className="unit-link" onClick={() => handleUnitClick(unitNumber)}>
                      {unit}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          <div className={`examenes ${selectedUnit ? "small-cards" : ""}`}>
            {isUnitEmpty ? (
              <p className="no-examenes-message">This unit does not contain any examenes at the moment.</p>
            ) : isSearchUnitEmpty ? (
              <p className="no-examenes-message">
                This unit does not exist at the moment. "{searchQuery}"
              </p>
            ) : (
              filteredExamenes.map((examen) => (
                <div key={examen.id} className="examen-card">
                  <Link to={examen.link} className="examen-link">
                    <div className="examen-image-container">
                      <img src={logoexamen} alt="Logo Examen" className="logo-examen" />
                    </div>
                    <p className="examen-title">Unit {examen.unidad}: {examen.title}</p>
                  </Link>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Examenes;
